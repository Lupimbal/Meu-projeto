# Site de Hotel para Hospedagem

## Status do Projeto
Em desenvolvimento

## Tecnologias Aplicadas
- HTML
- CSS
- JavaScript
- MySQL

## Time de Desenvolvedores
- [Luiza Oliveira Alves Ferreira]


## Objetivo do Software
O objetivo deste software é permitir que os usuários cadastrem-se e agendem hospedagens em um hotel, oferecendo opções de quartos e a quantidade de dias, além de fornecer uma descrição do hotel e suas qualidades.

## Funcionalidades do Sistema (Requisitos)
- Tela de cadastro de usuários
- Tela de login de usuários
- Agendamento de hospedagem com opções de quartos e quantidade de dias
- Escolha do tipo de quarto
- Descrição do hotel e suas qualidades
